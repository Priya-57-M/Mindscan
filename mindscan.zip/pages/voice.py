import streamlit as st
import speech_recognition as sr
import pyttsx3
import threading
import pythoncom
from textblob import TextBlob

# Initialize the text-to-speech engine
def init_tts_engine():
    pythoncom.CoInitialize()  # Initialize COM for pyttsx3
    return pyttsx3.init()

# Function to recognize speech
def recognize_speech():
    st.write("🎤 Say something... Let me know how you're feeling.")  # Let the user know the mic is listening
    r = sr.Recognizer()

    with sr.Microphone() as source:
        try:
            r.adjust_for_ambient_noise(source)  # To account for ambient noise
            st.write("Listening... Please speak.")
            audio = r.listen(source)

            # Use Google Web Speech API to recognize the speech
            text = r.recognize_google(audio)
            st.success(f"You said: {text}")  # Display what was recognized
            
            # Display mood analysis and respond in text
            response = display_mood_analysis(text)
            
            # Also respond in voice (TTS) in a separate thread
            threading.Thread(target=speak, args=(response,)).start()

        except Exception as e:
            st.error(f"Sorry, could not process audio. Error: {str(e)}")

# Function to display mood analysis and return suggestions
def display_mood_analysis(text):
    # Use TextBlob for sentiment analysis
    blob = TextBlob(text)
    sentiment_score = blob.sentiment.polarity  # Range: -1 (negative) to 1 (positive)
    
    # Analyzing sentiment and providing suggestions
    if sentiment_score > 0.7:
        response = (
            "I'm so happy to hear you're in a great mood! Keep spreading that positivity! 😊\n"
            "Remember, staying positive helps keep your mind clear and focused. Keep up the amazing energy!"
        )
    elif sentiment_score > 0.4:
        response = (
            "It sounds like you're in a good mood, that's awesome! 😄\n"
            "Is there something in particular making you feel good today? Let's keep the positive vibes going!"
        )
    elif sentiment_score > 0:
        response = (
            "You're feeling okay, that's fine! Sometimes it's great to just be in the middle ground. 👍\n"
            "Would you like to talk more about how you're feeling, or share something you enjoyed today?"
        )
    elif sentiment_score == 0:
        response = (
            "It seems like you're feeling neutral today. That's completely normal. 🌿\n"
            "Would you like to share anything on your mind or just chat?"
        )
    elif sentiment_score > -0.4:
        response = (
            "I'm sorry you're feeling a little down. It's okay, we all have those days. 😔\n"
            "Sometimes talking about it helps. Would you like to share what's going on, or should we try a quick breathing exercise?"
        )
    elif sentiment_score > -0.7:
        response = (
            "It seems like you're feeling quite low right now. I'm really sorry you're going through this. 😢\n"
            "It's okay to feel sad, and I'm here to listen. Would you like to try focusing on your breathing for a minute? It can help calm your mind."
        )
    else:
        response = (
            "I can sense you're feeling overwhelmed. 😞\n"
            "It's really important to take a moment for yourself. Would you like some breathing exercises, or perhaps some tips for managing stress?"
        )

    st.write(response)  # Display response in text
    return response

# Function to speak out the response using TTS
def speak(text):
    # Initialize COM in the main thread (necessary for pyttsx3)
    pythoncom.CoInitialize()
    
    engine = init_tts_engine()  # Initialize the TTS engine
    engine.say(text)
    engine.runAndWait()

# Run function for Streamlit interface
def run():
    st.title("🎙️ Voice-Based Emotion Detector")

    # Button to start speech recognition
    if st.button("🔊 Start Speech Recognition"):
        st.write("🎤 Listening... Please speak into the microphone.")
        recognize_speech()  # Trigger speech recognition when the button is clicked

    st.write("\n")
    st.write("If the mic is not working or you prefer text input, you can try typing in your mood below.")
    text_input = st.text_input("Type your mood or message here:")
    
    if text_input:
        st.write(f"You typed: {text_input}")
        response = display_mood_analysis(text_input)  # Analyze the typed text for mood
        threading.Thread(target=speak, args=(response,)).start()  # Provide spoken feedback

    # Display a suggestion to the user if they are in a neutral or negative mood
    st.write("\n")
    st.write("Would you like some tips or relaxation exercises?")
    if st.button("Get Relaxation Tips"):
        st.write("Here are a few tips for relaxation:")
        st.write("1. Try some deep breathing exercises.")
        st.write("2. Take a walk and enjoy the fresh air.")
        st.write("3. Listen to soothing music.")
        st.write("4. Practice mindfulness or meditation.")

# Run the app
if __name__ == "__main__":
    run()
