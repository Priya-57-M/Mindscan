import streamlit as st
import random


# Function for Rock Paper Scissors game
def rock_paper_scissors():
    st.title("Rock Paper Scissors Game")
    
    options = ["Rock", "Paper", "Scissors"]
    
    user_choice = st.selectbox("Choose your option", options)
    computer_choice = random.choice(options)
    
    st.write(f"Computer chose: {computer_choice}")
    
    if user_choice == computer_choice:
        st.write("It's a tie!")
    elif (user_choice == "Rock" and computer_choice == "Scissors") or \
         (user_choice == "Paper" and computer_choice == "Rock") or \
         (user_choice == "Scissors" and computer_choice == "Paper"):
        st.write("You win!")
    else:
        st.write("You lose!")


# Function for Number Guessing game
def number_guessing_game():
    st.title("Number Guessing Game")
    
    number = random.randint(1, 100)
    attempts = 0
    guessed = False
    
    guess = st.number_input("Guess a number between 1 and 100", min_value=1, max_value=100, step=1)
    if guess:
        attempts += 1
        
        if guess < number:
            st.write("Too low! Try again.")
        elif guess > number:
            st.write("Too high! Try again.")
        else:
            guessed = True
            st.write(f"Congratulations! You've guessed the number in {attempts} attempts.")
    
    if guessed:
        st.button("Play Again", on_click=number_guessing_game)


# Function for Trivia Quiz game
def trivia_quiz():
    st.title("Trivia Quiz Game")
    
    questions = {
        "What is the capital of France?": ["A. Berlin", "B. Madrid", "C. Paris", "D. Rome", "C"],
        "Which planet is known as the Red Planet?": ["A. Venus", "B. Mars", "C. Jupiter", "D. Saturn", "B"],
        "Who wrote 'Romeo and Juliet'?": ["A. Shakespeare", "B. Dickens", "C. Hemingway", "D. Twain", "A"]
    }
    
    score = 0
    for question, options in questions.items():
        st.write(question)
        answer = st.radio("Choose your answer:", options[:-1])
        
        if answer == options[-1]:
            score += 1
            st.write("Correct!")
        else:
            st.write("Incorrect!")
    
    st.write(f"You scored {score}/{len(questions)}.")


# Main function to display game options
def main():
    st.set_page_config(page_title="Game Hub", page_icon="🎮")
    
    st.title("🎮 Welcome to the Game Hub! 🎮")
    
    game_choice = st.selectbox("Choose a game to play:", ["Rock Paper Scissors", "Number Guessing Game", "Trivia Quiz Game"])
    
    if game_choice == "Rock Paper Scissors":
        rock_paper_scissors()
    elif game_choice == "Number Guessing Game":
        number_guessing_game()
    elif game_choice == "Trivia Quiz Game":
        trivia_quiz()


# Run the app
if __name__ == "__main__":
    main()