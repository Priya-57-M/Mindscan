import streamlit as st

# --- Emotion detection function ---
def detect_emotion(text):
    text = text.lower()
    if any(word in text for word in ["happy", "joyful", "content", "excited", "delighted", "cheerful", "blissful"]):
        return "joy"
    elif any(word in text for word in ["sad", "depressed", "gloomy", "miserable", "heartbroken", "lonely", "blue", "sorrowful"]):
        return "sadness"
    elif any(word in text for word in ["angry", "mad", "irritated", "frustrated", "furious", "annoyed", "enraged", "livid"]):
        return "anger"
    elif any(word in text for word in ["scared", "anxious", "fearful", "terrified", "nervous", "worried", "uneasy", "panicked"]):
        return "fear"
    elif any(word in text for word in ["surprised", "shocked", "amazed", "astonished", "dumbfounded"]):
        return "surprise"
    elif any(word in text for word in ["love", "affection", "caring", "passionate", "fond", "adoring"]):
        return "love"
    else:
        return "neutral"

# --- AI suggestion based on emotion ---
def get_ai_suggestion(emotion):
    suggestions = {
        "joy": "You're feeling great! Embrace your positive energy and share your joy.",
        "sadness": "It's okay to feel sad. Talk to a friend or do something calming.",
        "anger": "Anger can be overwhelming. Try deep breathing or write down your thoughts.",
        "fear": "Try grounding exercises or reach out for support.",
        "surprise": "Take time to reflect and let your emotions settle.",
        "love": "Express your love or engage in self-care.",
        "neutral": "You're calm and balanced. Do something that brings joy.",
    }
    return suggestions.get(emotion, "Every feeling is valid. Stay kind to yourself.")

# --- YouTube video recommendation ---
def get_youtube_links(emotion):
    youtube_links = {
        "sadness": ["https://www.youtube.com/watch?v=inpok4MKVLM"],
        "fear": ["https://www.youtube.com/watch?v=inpok4MKVLM"],
        "anger": ["https://www.youtube.com/watch?v=inpok4MKVLM"],
        "joy": ["https://www.youtube.com/watch?v=ZToicYcHIOU"],
        "surprise": ["https://www.youtube.com/watch?v=ZToicYcHIOU"],
        "love": ["https://www.youtube.com/watch?v=MIr3RsUWrdo"],
        "neutral": ["https://www.youtube.com/watch?v=ZToicYcHIOU"],
    }
    return youtube_links.get(emotion.lower(), youtube_links["neutral"])

# --- Main function for Text Emotion Analyzer ---
def run():
    st.title("📝 MindScan - Text Emotion Analyzer")

    user_input = st.text_area("🧠 Enter your thoughts or feelings:")

    if st.button("🔍 Analyze Text"):
        if not user_input.strip():
            st.warning("Please enter something to analyze.")
            return

        emotion = detect_emotion(user_input)
        suggestion = get_ai_suggestion(emotion)
        youtube_links = get_youtube_links(emotion)

        st.success(f"**🧠 Detected Emotion:** {emotion.capitalize()}")
        st.markdown(f"**💡 AI Suggestion:** {suggestion}")

        if youtube_links:
            st.markdown("**🎥 Recommended Video for You:**")
            for link in youtube_links:
                st.video(link)

    # Book appointment button always available at the bottom
    st.markdown("---")
    st.subheader("💬 Want to speak with a doctor?")
    if st.button("🩺 Book an Appointment"):
        st.session_state.page = "Book_Appointment"
        st.rerun()  # ✅ Replaces deprecated st.experimental_rerun() 