import streamlit as st
import importlib

st.title("🧠 MindScan – Mental Health AI")

# Sidebar input options
option = st.sidebar.radio("Choose input method", ("Text Input", "Voice Input", "Live Chatbot"))

# Dynamically import and run the selected module
if option == "Text Input":
    st.write("Text input module is loading...")
    text_input = importlib.import_module("text_input")
    text_input.run()
    st.write("Text input module is running.")

elif option == "Voice Input":
    try:
        st.write("Voice input module is loading...")
        voice_module = importlib.import_module("voice")  # Importing your voice.py
        voice_module.run()  # Running the voice-based emotion detector
        st.write("Voice input module is running.")
    except Exception as e:
        st.error(f"Error loading the voice module: {e}")

elif option == "Live Chatbot":
    st.write("Live Chatbot module is loading...")
    chatbot_module = importlib.import_module("chatbot")
    chatbot_module.run()
    st.write("Chatbot module is running.")
