import tempfile
import os
import av
import time
import numpy as np
from deepface import DeepFace
import speech_recognition as sr
import streamlit as st
from streamlit_webrtc import webrtc_streamer, WebRtcMode, VideoProcessorBase, AudioProcessorBase
import scipy.io.wavfile as wav  # Added import here

# Mood suggestion function
def get_mood_suggestions(mood):
    suggestions = {
        "happy": "You're in a great mood! 😊 Try doing something fun or relaxing.",
        "sad": "It's okay to feel sad. Try reading, journaling, or talking to someone you trust.",
        "angry": "Take a deep breath, step away for a moment, and try to calm your thoughts.",
        "surprise": "Something unexpected? Reflect on it and talk it out if needed.",
        "fear": "Try grounding yourself with mindfulness or breathing exercises.",
        "disgust": "You may need a break or a change of scenery. Self-care matters!",
        "neutral": "You're in a balanced state. Maybe explore something creative today.",
    }
    return suggestions.get(mood, "Whatever you're feeling, I'm here to listen and help.")

def live_chatbot():
    st.title("🧠 MindScan Live ChatBot")
    st.write("🎥 Speak for 10 seconds. Your face and voice will be analyzed.")

    # Initialize session state
    if "captured_video" not in st.session_state:
        st.session_state.captured_video = None
    if "captured_audio" not in st.session_state:
        st.session_state.captured_audio = None

    audio_file_path = os.path.join(tempfile.gettempdir(), "captured_audio.wav")

    # Video processor class
    class VideoProcessor(VideoProcessorBase):
        def __init__(self):
            self.last_frame = None

        def recv(self, frame):
            img = frame.to_ndarray(format="bgr24")
            self.last_frame = img
            return av.VideoFrame.from_ndarray(img, format="bgr24")

    # Audio processor class
    class AudioProcessor(AudioProcessorBase):
        def __init__(self):
            self.frames = []

        def recv(self, frame):
            self.frames.append(frame.to_ndarray())
            return frame

    # Stream setup (removed ClientSettings)
    ctx = webrtc_streamer(
        key="live_analysis",
        mode=WebRtcMode.SENDRECV,
        video_processor_factory=VideoProcessor,
        audio_processor_factory=AudioProcessor,
        media_stream_constraints={"video": True, "audio": True},  # Direct stream constraints
        rtc_configuration={"iceServers": [{"urls": ["stun:stun.l.google.com:19302"]}]}  # ICE servers configuration
    )

    if ctx.state.playing:
        st.success("✅ Streaming started. Please speak and look at the camera for 10 seconds.")
        time.sleep(10)
        st.success("✅ Recording finished.")

        # Save video frame
        if ctx.video_processor and ctx.video_processor.last_frame is not None:
            st.session_state.captured_video = ctx.video_processor.last_frame
            st.image(st.session_state.captured_video, channels="BGR", caption="📸 Captured Frame")

        # Save audio
        if ctx.audio_processor and ctx.audio_processor.frames:
            audio_data = np.concatenate(ctx.audio_processor.frames, axis=0)
            audio_data = np.int16(audio_data)
            wav.write(audio_file_path, 16000, audio_data)  # Writing the audio to a .wav file
            st.session_state.captured_audio = audio_file_path
            st.audio(st.session_state.captured_audio, format="audio/wav")

    if st.button("📤 Analyze Emotions"):
        with st.spinner("Analyzing your facial and vocal emotions..."):

            # Analyze facial emotion
            if st.session_state.captured_video is not None:
                try:
                    result = DeepFace.analyze(
                        st.session_state.captured_video,
                        actions=["emotion"],
                        enforce_detection=False
                    )
                    dominant = result[0]["dominant_emotion"] if isinstance(result, list) else result.get("dominant_emotion", "Unknown")
                    st.success(f"🧠 Facial Emotion Detected: {dominant}")
                    st.write("💬 " + get_mood_suggestions(dominant))
                except Exception as e:
                    st.error(f"❌ Facial analysis failed: {e}")

            # Transcribe and analyze voice
            if st.session_state.captured_audio:
                recognizer = sr.Recognizer()
                try:
                    with sr.AudioFile(st.session_state.captured_audio) as source:
                        audio = recognizer.record(source)
                        text = recognizer.recognize_google(audio)
                        st.success(f"🗣 Transcribed Speech: {text}")

                        if "sad" in text.lower():
                            st.info("You sound sad. Try relaxing and talking to someone you trust.")
                        elif "angry" in text.lower():
                            st.info("Sounds like anger. Consider deep breathing or going for a short walk.")
                        else:
                            st.info("Thank you for sharing. I'm here if you need support.")

                except Exception as e:
                    st.error(f"❌ Voice analysis failed: {e}")

    if st.button("🔙 Back to Home"):
        st.session_state.page = "Home"
        st.rerun()


    st.write("⚠️ If nothing is displaying, please check that you've allowed camera/microphone permissions in your browser.")

if __name__ == "__main__":
    live_chatbot()
