import streamlit as st

def speak(message, gender):
    st.write(f"[Voice Output] {message} ({gender})")

def book_appointment():
    st.title("📅 Book Your Appointment")

    # Region-wise hospitals and doctors
    regions = {
        "Bengaluru": {
            "Apollo Hospital": ["Dr. Asha Rao", "Dr. Rahul Mehta"],
            "Fortis Hospital": ["Dr. Priya Singh", "Dr. Sanjay Kumar"]
        },
        "Mysuru": {
            "JSS Hospital": ["Dr. Shweta Nair", "Dr. Anand Raj"],
            "Narayana Multispeciality": ["Dr. Kumar R", "Dr. Neha Patil"]
        },
        "Mangaluru": {
            "A J Hospital": ["Dr. Deepa Das", "Dr. Ravi Joshi"],
            "KMC Hospital": ["Dr. Suresh Bhat", "Dr. Sneha Shetty"]
        },
        "Hubballi": {
            "SDM Hospital": ["Dr. Nikhil Gowda", "Dr. Kavya Rao"],
            "Lifeline Hospital": ["Dr. Pooja Desai", "Dr. Ramesh Hegde"]
        },
        "Belagavi": {
            "KLES Hospital": ["Dr. Meghana Pai", "Dr. Vishal S"],
            "Lakeview Hospital": ["Dr. Arun R", "Dr. Anjali N"]
        },
        "Kalaburagi": {
            "Basaveshwara Hospital": ["Dr. Manjunath R", "Dr. Soumya D"],
            "ESI Hospital": ["Dr. Farhan Khan", "Dr. Vaishnavi S"]
        },
        "Ballari": {
            "VIMS Hospital": ["Dr. Lokesh H", "Dr. Padmini S"],
            "Golden Hospital": ["Dr. Rajat Kulkarni", "Dr. Tanya M"]
        },
        "Tumakuru": {
            "Sri Siddhartha Hospital": ["Dr. Vinod M", "Dr. Shruthi J"],
            "Bapuji Hospital": ["Dr. Raghav D", "Dr. Harini B"]
        },
        "Shivamogga": {
            "McGann Hospital": ["Dr. Jyoti Rao", "Dr. Tejas R"],
            "Nanjappa Hospital": ["Dr. Deepak S", "Dr. Divya N"]
        },
        "Davanagere": {
            "SSIMS Hospital": ["Dr. Mahesh B", "Dr. Reshma S"],
            "Chigateri Hospital": ["Dr. Naveen K", "Dr. Gayathri L"]
        }
    }

    region = st.selectbox("Select Region in Karnataka", list(regions.keys()))
    hospitals = regions[region]

    name = st.text_input("Name")
    age = st.number_input("Age", 1, 120)
    gender = st.selectbox("Gender", ["Male", "Female", "Other"])
    hospital = st.selectbox("Hospital", list(hospitals.keys()))
    doctor = st.selectbox("Doctor", hospitals[hospital])
    date = st.date_input("Date")
    time = st.time_input("Time")

    if st.button("Confirm Appointment"):
        if name:
            st.success(f"Appointment confirmed with {doctor} on {date} at {time} in {hospital}, {region}.")
            speak(f"Appointment confirmed with {doctor} on {date} at {time} in {hospital}, {region}", gender.lower())
        else:
            st.error("Please complete all fields.")

if __name__ == "__main__":
    book_appointment()
