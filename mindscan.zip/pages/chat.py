import streamlit as st
from transformers import pipeline
from utils.tts import speak

emotion_classifier = pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base")

def chat_ui():
    st.title("🧠 MindScan - ChatBot")

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    user_input = st.chat_input("How are you feeling today?")
    if user_input:
        with st.chat_message("user"):
            st.markdown(user_input)

        emotion = emotion_classifier(user_input)[0]["label"]
        response = generate_bot_response(emotion)
        with st.chat_message("assistant"):
            st.markdown(response)
            speak(response)

        st.session_state.chat_history.extend([("user", user_input), ("assistant", response)])

    for role, msg in st.session_state.chat_history:
        with st.chat_message(role):
            st.markdown(msg)

def generate_bot_response(emotion):
    responses = {
        "happy": "You seem happy! That's wonderful.",
        "sad": "You sound a bit sad. I'm here for you.",
        "angry": "You seem upset. Let’s talk it through.",
        "fear": "You seem anxious. You're not alone.",
        "surprise": "Surprised? I hope it’s something good!",
        "neutral": "You sound calm. Tell me more.",
        "tired": "Its okay, you've done a great job.",
    }
    return responses.get(emotion, "I’m here with you.")
