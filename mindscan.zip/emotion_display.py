import streamlit as st
import matplotlib.pyplot as plt
from transformers import pipeline
from utils.tts import speak

emotion_classifier = pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base")

def analyze_mood(user_input):
    return emotion_classifier(user_input, top_k=5)

def display_mood_analysis(user_input, speaker_gender):
    results = analyze_mood(user_input)
    labels = [r['label'] for r in results]
    scores = [r['score'] for r in results]

    fig, ax = plt.subplots()
    ax.bar(labels, scores, color='skyblue')
    st.pyplot(fig)

    top = max(results, key=lambda x: x['score'])
    st.success(f"Detected Emotion: {top['label']} ({round(top['score']*100)}%)")
    speak(f"You seem to be feeling {top['label']}", speaker_gender)
