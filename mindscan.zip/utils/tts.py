from gtts import gTTS
import uuid
import streamlit as st
import pyttsx3
import time

def speak(text, speaker_gender="female"):
    tld = 'com' if speaker_gender == "male" else 'co.uk'
    
    try:
        # Attempt to use Google TTS
        tts = gTTS(text=text, lang='en', tld=tld)
        filename = f"temp_{uuid.uuid4()}.mp3"
        tts.save(filename)
        st.audio(filename, format="audio/mp3")
        
    except Exception as e:
        st.error(f"Google TTS failed: {e}. Trying offline TTS.")
        
        # Fallback to pyttsx3 for offline TTS
        try:
            engine = pyttsx3.init()
            engine.save_to_file(text, f"temp_{uuid.uuid4()}.mp3")
            engine.runAndWait()
            filename = f"temp_{uuid.uuid4()}.mp3"
            st.audio(filename, format="audio/mp3")
        except Exception as fallback_error:
            st.error(f"Offline TTS failed: {fallback_error}")
            
        time.sleep(2)  # Optional delay for retry or to prevent rapid failures
