def book_appointment():
    st.title("📅 Book Your Appointment")

    # State → Hospital → Doctors mapping
    hospitals_by_state = {
        "Karnataka": {
            "Apollo Hospital, Bengaluru": ["Dr. Asha Mehta", "Dr. Rahul Singh"],
            "Fortis Hospital, Bengaluru": ["Dr. Priya Reddy", "Dr. Sanjay Kumar"]
        },
        "Maharashtra": {
            "Nanavati Hospital, Mumbai": ["Dr. Sneha Patil", "Dr. Arjun Deshmukh"],
            "Hiranandani Hospital, Mumbai": ["Dr. Nidhi Shah", "Dr. Aman Joshi"]
        },
        "Tamil Nadu": {
            "Apollo Hospital, Chennai": ["Dr. Kavitha Iyer", "Dr. Rajesh Nair"],
            "Fortis Malar, Chennai": ["Dr. Divya Shankar", "Dr. Naveen Thomas"]
        },
        "Delhi": {
            "AIIMS, Delhi": ["Dr. Neha Batra", "Dr. Vikram Khanna"],
            Max Hospital, Delhi": ["Dr. Pooja Anand", "Dr. Ramesh Yadav"]
        },
        "Telangana": {
            "Yashoda Hospital, Hyderabad": ["Dr. Suresh Rao", "Dr. Anjali Verma"],
            "Continental Hospital, Hyderabad": ["Dr. Vishal Jain", "Dr. Rekha Rao"]
        },
        "West Bengal": {
            "Fortis, Kolkata": ["Dr. Aditya Ghosh", "Dr. Meera Dutta"],
            "AMRI Hospital, Kolkata": ["Dr. Tapan Banerjee", "Dr. Indrani Das"]
        }
        # Add more states as needed
    }

    # --- Input Fields ---
    name = st.text_input("🧑 Patient Name")
    age = st.number_input("🎂 Age", min_value=1, max_value=100, step=1)
    gender = st.selectbox("⚧ Gender", ["Male", "Female", "Other"])

    # --- State selection ---
  state = st.selectbox("🌍 Select Your State", list(hospitals_by_state.keys()))

    # --- Hospitals filtered by state ---
    hospitals = list(hospitals_by_state[state].keys())
    hospital = st.selectbox("🏥 Choose Hospital", hospitals)

    # --- Doctors filtered by hospital ---
    doctors = hospitals_by_state[state][hospital]
    doctor = st.selectbox("👨‍⚕️ Select Doctor", doctors)

    # --- Appointment Date & Time ---
    date = st.date_input("📆 Select Appointment Date")
    time = st.time_input("⏰ Select Start Time")

    # --- Slot Duration ---
    slot_duration = st.selectbox("🕒 Slot Duration", ["20 minutes", "30 minutes"])

    if st.button("✅ Confirm Appointment"="confirm_appointment_button"):
        if name:
            st.success(
                f"📌 Appointment booked for **{name}**, Age {age}, with **{doctor}** at **{hospital}**, {state} "
                f"on **{date}** at **{time.strftime('%I:%M %p')}** for **{slot_duration}**."
            )
            # Optional: Add notification, email, SMS trigger logic here
        else:
            st.error("🚫 Please complete all fields to confirm the appointment.")
