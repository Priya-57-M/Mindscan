import streamlit as st
import importlib

# --- Main function to handle page navigation ---
def home():
    st.title("🧠 MindScan – Mental Wellness Companion")

    # Step 1: Ask for user's name
    if "user_name" not in st.session_state:
        st.session_state.user_name = ""

    if not st.session_state.user_name:
        name_input = st.text_input("Hi there! What's your name?")
        if name_input:
            st.session_state.user_name = name_input.strip()
            st.rerun() # Rerun the app after the name is entered
        return  # Wait until name is entered

    # Step 2: Greet the user
    st.success(f"Welcome, {st.session_state.user_name}! 😊")

    # Step 3: Choose communication method
    st.markdown("### How would you like to begin?")
    method = st.radio("Select a communication mode:", ["Voice", "Text", "Live Video"])

    # Step 4: Route based on choice
    if st.button("Start"):
       st.session_state.page = method  # Set the current page to the selected method
       st.rerun()  # Rerun to update the app with the chosen mode


# --- Handle page navigation ---
if 'page' not in st.session_state:
    st.session_state.page = "Home"

# Page navigation logic
if st.session_state.page == "Home":
    home()  # Show home page content

elif st.session_state.page == "Voice":
    st.subheader("🎤 Voice Recognition Page")
    st.info("Voice recognition functionality will be added here.")

elif st.session_state.page == "Text":
    # Import the text_input page from the 'pages' folder
    text_module = importlib.import_module("pages.text_input")
    text_module.run()  # Call the run function from text_input.py

elif st.session_state.page == "Live Video":
    st.subheader("🎥 Live Video Page")
    st.info("Live video interaction functionality will be added here.")
